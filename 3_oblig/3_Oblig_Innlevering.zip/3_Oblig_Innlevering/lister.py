# List with numbers
liste=[1,2,3]
liste.append(4)

# Empty array
navn_liste= []

# Ask for input from user
for i in range(1,5):
    navn_liste.append(input("Navn " + str(i) + ": "))

#Check if name is in the list
if "Jose" in navn_liste:
    print("Du husket meg!")
else:
    print("Glemte du meg?")

#New list for the sum and the product
sumProduktListe = []
#Add and add the sum to the list
sumProduktListe.append(sum(liste))

# Function to calculate the product of the numbers in the list
def produkt(liste):
    produkt = 1
    for i in liste:
        produkt *= i
    return produkt

# Recursive variant to calculate the product. Just for fun.
def produkt2(l, i):
    if i == 0:
        return l[i]
    return l[i] * produkt2(l, i - 1)

# Append the product to the list
sumProduktListe.append(produkt2(liste, len(liste) - 1))

print(sumProduktListe)

