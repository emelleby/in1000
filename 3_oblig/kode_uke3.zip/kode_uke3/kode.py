min_mengde = set([1,5,1,1])
print(min_mengde)
