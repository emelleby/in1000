hovedstad = {"Sverige":"Stockholm", "Norge":"Oslo"}
land = input("Velg land i nordre Skandinavia: ")
print(hovedstad[land])
