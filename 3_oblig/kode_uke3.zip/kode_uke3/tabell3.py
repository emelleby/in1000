tab = [ [5,3], [3,5] ]
alle_like = (tab[0][0]==tab[1][1]) and (tab[1][0]==tab[0][1])
print(alle_like)
