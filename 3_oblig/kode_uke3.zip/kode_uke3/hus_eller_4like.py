kast = [3,3,4,3,3]
ulike = set(kast)
print( len(ulike)==2 )
