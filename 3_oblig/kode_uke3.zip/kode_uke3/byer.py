vest = ["Hallo", "Bergen"]
midt = ["Trondheim"]
print( vest + midt)
nord = ["Alta", "Kautokeino"]
vest = nord + vest
print(vest)
nord.append("Narvik")
print(nord)
lengde = len(vest+nord)
print(lengde)
