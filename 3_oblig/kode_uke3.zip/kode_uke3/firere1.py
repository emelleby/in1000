kast = []
kast.append(int(input("Kast 1: ")))
kast.append(int(input("Kast 2: ")))
kast.append(int(input("Kast 3: ")))
kast.append(int(input("Kast 4: ")))
kast.append(int(input("Kast 5: ")))
