# Get input in Fahrenheit
fahrenheit = int(input("Grader i Fahrenheit: "))

print (fahrenheit)

#Convert Fahrenheit to Celsius
celsius = (fahrenheit - 32) * (5 / 9)

print (str(celsius) + " grader C")
