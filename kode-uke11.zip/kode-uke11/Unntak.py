
telefonbok = {}
telefonbok["Anna"] = 22334455
telefonbok["Bjarte"] = 12345678

tast = input("Tast inn navn paa den du soeker: ")

print(telefonbok[tast])
