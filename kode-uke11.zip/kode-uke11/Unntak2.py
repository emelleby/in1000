
tast = input("Fil som skal aapnes: ")


fil = open(tast)
for linje in fil:
    print(linje)
